# Charcoal.UI
GUI texture pack.

This pack is for 1.7.10 and specifically for GTNH modpack.

Works best with `use_machine_metal_tint` set to `false` in the gregtech config.

If you use a custom font with this resourcepack it may make writing unreadable in GUIs

<img src="https://imgur.com/rdF6lN4.png" />
<img src="https://imgur.com/05XLwtI.png" />


 If you find a missing or broken UI, bother me at ｔｙｒａｎｔ#5957



  
 


